
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getRaceCommentary(raceName: string, eventType: string, teamName: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a professional race commentator. Give a short (1 sentence), high-energy commentary on a ${eventType} for team "${teamName}" in the "${raceName}" race. Make it sound like Formula 1 or endurance racing.`,
    });
    return response.text || "Action on track!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The race continues with high intensity!";
  }
}

export async function getStewardAdvice(pitStopDetails: any) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `As a Race Steward, review this pit stop: ${JSON.stringify(pitStopDetails)}. Briefly state if the swap looks valid or if there's a safety concern (Endurance racing context). Keep it under 20 words.`,
    });
    return response.text || "Pit stop reviewed. No further action.";
  } catch (error) {
    return "Proceed with caution.";
  }
}
