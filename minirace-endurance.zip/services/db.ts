
import { initializeApp, getApp, getApps } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc, getDocs, collection, query, orderBy, deleteDoc } from 'firebase/firestore';
import { Race, RaceTeam, RaceHistoryEntry } from '../types';

const getFirebaseConfig = () => {
  const saved = localStorage.getItem('firebase_config');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      return null;
    }
  }
  return null;
};

const config = getFirebaseConfig();
const app = config ? (getApps().length === 0 ? initializeApp(config) : getApp()) : null;
const firestore = app ? getFirestore(app) : null;

export const db = {
  isLocalMode(): boolean {
    return !firestore;
  },

  async testConnection(newConfig: any): Promise<boolean> {
    try {
      // Use a unique name for the test app to avoid collisions
      const tempApp = initializeApp(newConfig, `testApp_${Date.now()}`);
      const tempDb = getFirestore(tempApp);
      
      // Attempt a write to a 'status' collection to verify permissions
      const testRef = doc(tempDb, 'status', 'connection_test');
      await setDoc(testRef, { last_ping: Date.now(), status: 'online' });
      
      // If we got here, config is valid and writeable
      localStorage.setItem('firebase_config', JSON.stringify(newConfig));
      return true;
    } catch (e) {
      console.error("Firebase Connection failed:", e);
      return false;
    }
  },

  disconnect() {
    localStorage.removeItem('firebase_config');
    window.location.reload();
  },

  async getRace(): Promise<Race | null> {
    if (!firestore) {
      const data = localStorage.getItem('apex_global_race');
      return data ? JSON.parse(data) : null;
    }
    try {
      const docRef = doc(firestore, 'races', 'current');
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data() as Race;
      }
      return null;
    } catch (e) { return null; }
  },

  async saveRace(race: Race | null): Promise<void> {
    if (!firestore) {
      if (race) localStorage.setItem('apex_global_race', JSON.stringify(race));
      else localStorage.removeItem('apex_global_race');
      return;
    }
    const docRef = doc(firestore, 'races', 'current');
    if (!race) {
      await deleteDoc(docRef);
    } else {
      await setDoc(docRef, race);
    }
  },

  async getTeams(): Promise<RaceTeam[]> {
    if (!firestore) {
      const data = localStorage.getItem('apex_global_teams');
      return data ? JSON.parse(data) : [];
    }
    try {
      const querySnapshot = await getDocs(collection(firestore, 'teams'));
      const teams: RaceTeam[] = [];
      querySnapshot.forEach((doc) => {
        teams.push(doc.data() as RaceTeam);
      });
      return teams;
    } catch (e) { return []; }
  },

  async saveTeams(teams: RaceTeam[]): Promise<void> {
    if (!firestore) {
      localStorage.setItem('apex_global_teams', JSON.stringify(teams));
      return;
    }
    const promises = teams.map(t => setDoc(doc(firestore, 'teams', t.id), t));
    await Promise.all(promises);
  },

  async getHistory(): Promise<RaceHistoryEntry[]> {
    if (!firestore) {
      const data = localStorage.getItem('apex_global_history');
      return data ? JSON.parse(data) : [];
    }
    try {
      const q = query(collection(firestore, 'history'), orderBy('date', 'desc'));
      const querySnapshot = await getDocs(q);
      const history: RaceHistoryEntry[] = [];
      querySnapshot.forEach((doc) => {
        history.push(doc.data() as RaceHistoryEntry);
      });
      return history;
    } catch (e) { return []; }
  },

  async saveHistory(history: RaceHistoryEntry[]): Promise<void> {
    if (!firestore) {
      localStorage.setItem('apex_global_history', JSON.stringify(history));
      return;
    }
    const promises = history.map(h => setDoc(doc(firestore, 'history', h.id), h));
    await Promise.all(promises);
  }
};
